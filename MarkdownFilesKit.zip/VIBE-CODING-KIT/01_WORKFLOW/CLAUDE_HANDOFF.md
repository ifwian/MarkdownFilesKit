# CLAUDE_HANDOFF.md — Cross-Account / Cross-Session Handoff Process

Use when switching Claude accounts, starting a new chat, or moving between Claude web, Claude Code, and OpenCode.
The fill-in form is `03_DELIVERY/HANDOFF_TEMPLATE.md`. The live file in the project is `docs/HANDOFF.md`.

## When to hand off
- A usage or context limit is near or reached (see emergency checkpoint in `DELIVERY_PROTOCOL.md`).
- The chat is very long and slow.
- The user switches tools or accounts.

## Outgoing side (MANDATORY)
1. Finish the current edit so the project is consistent (or mark `TODO(WIP)`).
2. Update `docs/HANDOFF.md` fully, with an **exact next task** (file names and what to do).
3. Update `TASK_TRACKER.md`, `DECISIONS_LOG.md`, `KNOWN_ISSUES.md`.
4. Build, verify, and attach the latest ZIP (`ZIP_CHECKLIST.md`). It must contain `docs/HANDOFF.md`.
5. Give the user the transfer package: **latest ZIP + the kit's `CLAUDE.md`** (already inside the ZIP) and Prompt 10 from `PROMPT_TEMPLATES.md`.

## Incoming side (MANDATORY)
1. Unzip the latest ZIP. Read `CLAUDE.md`, then `docs/HANDOFF.md`. Nothing else yet.
2. Check that the ZIP matches the handoff: filename/CP number, files listed as modified exist, project starts or loads.
3. If they disagree, trust the ZIP, then correct HANDOFF and note it.
4. Do **not** redo completed tasks or re-inspect the whole project. Use `ARCHITECTURE.md` as the map.
5. Respect "Restrictions / do not change" in the handoff and the locked decisions in `DECISIONS_LOG.md`.
6. Confirm in max 3 lines, then continue with the exact next task.
7. Continue the checkpoint numbering (CP05 follows CP04).

## Rules
- Handoff text is a summary; **files are the truth**. Never accept "tested" claims that are not recorded in HANDOFF's test section.
- Never start from an older ZIP if a newer one exists. Ask the user to confirm the filename if unsure.
- If the user only has an older ZIP, state that work after it is lost and list what HANDOFF says was done after it so it can be redone.

## Account-switch workflow (short)
Account A nears limit → emergency checkpoint → user downloads ZIP → user opens Account B → uploads ZIP and pastes Prompt 10 → B reads CLAUDE.md + HANDOFF → B continues → repeat.
Full guide: `USAGE_GUIDE.md`.
