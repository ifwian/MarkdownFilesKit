# TASK_TRACKER.md (template — live copy: `docs/TASK_TRACKER.md`)

One line per task. Update at every checkpoint. Do not add prose.
Status: `TODO` · `DOING` · `DONE` · `BLOCKED` · `DROPPED`

## Milestones
| ID | Milestone | Status | Checkpoint ZIP |
|---|---|---|---|
| M1 | Project setup, auth | TODO | |
| M2 | Core feature A | TODO | |
| M3 | Core feature B | TODO | |
| M4 | Responsive pass, validation, error states | TODO | |
| M5 | Testing, bug fixes, final review | TODO | |

## Tasks
| ID | Milestone | Task | Status | Files | Notes |
|---|---|---|---|---|---|
| T1 | M1 | Create DB schema | TODO | database/schema.sql | |
| T2 | M1 | Login/register | TODO | | |

## Rules
- Each milestone must leave the project working.
- Only one task `DOING` at a time.
- Mark `DONE` only after the check passes; record the check in HANDOFF.
- New requests from the user are added as tasks before work begins (one line).
- Dropped tasks stay listed as `DROPPED` with a reason.
