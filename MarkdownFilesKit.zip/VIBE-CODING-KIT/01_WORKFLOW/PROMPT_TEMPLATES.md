# PROMPT_TEMPLATES.md

Replace `[BRACKETS]`. All prompts assume `CLAUDE.md` is in the project (or attached). Keep them as short as shown.

### 1. Start a new website project
```
New website: [NAME]. Purpose: [1-2 sentences]. Users/roles: [..]. Stack: [stack | "recommend the simplest"]. Must-have pages/features: [..].
Fill docs/PROJECT_BRIEF.md and docs/ARCHITECTURE.md (short), plan milestones in docs/TASK_TRACKER.md, ask max 3 blocking questions, then build M1 and attach the ZIP.
```

### 2. Analyze an existing website
```
Analyze the attached ZIP. Follow CLAUDE.md session start. Detect stack, map folders, list the 10 most important files and any obvious bugs/risks. Save results in docs/ARCHITECTURE.md and docs/KNOWN_ISSUES.md. Change no code. Report in 10 lines max.
```

### 3. Implement a feature
```
Feature: [description]. Acceptance: [what must work]. Touch only what is needed; keep the current stack. Milestone-by-milestone, check each one, update HANDOFF, attach the ZIP.
```

### 4. Fix bugs
```
Bug: [what happens] Expected: [what should happen]. Steps: [..]. Find the cause first (grep/targeted reads), apply the smallest fix, verify, record in KNOWN_ISSUES.md, attach the ZIP.
```

### 5. Improve UI/UX
```
Improve UI of [page/area]. Follow docs/kit/02_WEBSITE_DEVELOPMENT/DESIGN_GUIDELINES.md. Goals: [modern look / spacing / mobile / states]. Do not change functionality or structure. Check desktop, tablet, mobile. Attach the ZIP.
```

### 6. Review code
```
Review [files/area] for bugs, security, readability, and beginner-friendliness. Report findings by severity with file:line and the smallest fix. Do not edit until I approve.
```

### 7. Refactor without breaking functionality
```
Refactor [area] to [goal]. Behavior must stay identical. Checkpoint ZIP first, work in small steps, run the relevant checks after each, stop and report if anything breaks. Attach the ZIP.
```

### 8. Test the website
```
Test [whole site | area] using docs/kit/02_WEBSITE_DEVELOPMENT/TESTING_CHECKLIST.md. Actually exercise forms, buttons, auth, roles, and error cases. Report pass/fail table, fix only failures I approve, record results in HANDOFF.
```

### 9. Prepare a ZIP checkpoint
```
Create a checkpoint now: update HANDOFF and TASK_TRACKER, build the full ZIP per ZIP_CHECKLIST.md, verify it opens and contains HANDOFF.md, attach it.
```

### 10. Transfer work to another Claude account
```
Continue this project. Unzip the attached latest ZIP. Read CLAUDE.md then docs/HANDOFF.md only. Verify the ZIP matches the handoff, confirm in 3 lines, then do the exact next task. Do not redo finished work or re-inspect everything. Checkpoint as CLAUDE.md requires.
```
Outgoing side: `Limits near. Do an emergency checkpoint: finish the current edit, fully update HANDOFF, attach the latest verified ZIP.`

### 11. Finalize a complete website
```
Finalize the project. Run docs/kit/03_DELIVERY/FINAL_REVIEW.md and TESTING_CHECKLIST.md, fix blockers, update README from README_TEMPLATE.md, clean unused files, attach the final ZIP and a 10-line summary.
```

### 12. Explain code for academic defense
```
Prepare me for defending [feature/project]. In simple language: what each main file does, the data flow of [feature], why we chose this stack/design, DB tables and relationships, 10 likely panel questions with short answers. Save to docs/DEFENSE_NOTES.md.
```
