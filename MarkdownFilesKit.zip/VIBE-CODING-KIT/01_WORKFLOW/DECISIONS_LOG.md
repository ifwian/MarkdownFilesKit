# DECISIONS_LOG.md (template — live copy: `docs/DECISIONS_LOG.md`)

Record decisions that a future AI account must not undo. Keep each entry to about 4 lines. Append only.

## Locked decisions (do not change without user approval)
- D-001 Stack: [e.g. HTML/CSS/JS + PHP 8 + MySQL 8 + Bootstrap 5]
- D-002 [e.g. Authentication uses PHP sessions, no JWT]

## Log
```
D-00X | YYYY-MM-DD | Title
Decision: <what was decided>
Reason: <why, 1 line>
Alternatives rejected: <short>
Approved by: user | AI-proposed (pending approval)
```

## Rules
- Log: stack choices, new dependencies, database design choices, folder structure changes, security approach, anything the user said "always"/"never" about.
- AI may propose, but changes to locked decisions need explicit user approval.
- Reversing a decision: add a new entry referencing the old one. Never delete history.
