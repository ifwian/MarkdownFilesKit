# USAGE_GUIDE.md

## One-time project setup (all tools)
1. Copy `00_GLOBAL_RULES/CLAUDE.md` to the **project root**.
2. Copy the whole kit folder to `docs/kit/` inside the project.
3. Create `docs/` live files from templates: `HANDOFF.md` (from `03_DELIVERY/HANDOFF_TEMPLATE.md`), `TASK_TRACKER.md`, `DECISIONS_LOG.md`, `KNOWN_ISSUES.md`, `PROJECT_BRIEF.md`, `ARCHITECTURE.md`. (Or ask the AI: "Create the docs/ files from docs/kit templates.")
4. Zip the project. Now the kit travels with every ZIP.

## Claude web (claude.ai)
- Enable **Code execution and file creation** in Settings so Claude can unzip, edit, and create ZIPs.
- New project: upload the kit (or the project ZIP that contains it) and paste Prompt 1.
- Existing project: upload the latest project ZIP and paste Prompt 2 (analyze) or Prompt 3/4 (feature/bug).
- Claude must follow `CLAUDE.md`: ZIP attached at the end of every turn that changed files, checkpoints after each milestone.
- Download the ZIP **immediately** after each reply. Keep only the latest.
- If a chat grows long, start a new chat and use Prompt 10 with the latest ZIP.

## Claude Code
- `CLAUDE.md` in the project root is loaded automatically at session start.
- Reference files with `@docs/HANDOFF.md` when needed.
- Use `/clear` between unrelated tasks and `/compact` when context grows.
- Checkpoint = Git commit + HANDOFF update (see "Local tools" in `DELIVERY_PROTOCOL.md`). Make a ZIP with `make_checkpoint.sh` only when moving to Claude web or another account.
- Before stopping for the day or when usage is low: update HANDOFF and commit.

## OpenCode (VS Code)
- OpenCode reads `AGENTS.md`, and falls back to `CLAUDE.md` if there is no `AGENTS.md`. To be safe, create `AGENTS.md` containing one line: `Read and follow CLAUDE.md.`
- *(If your version supports an `instructions` list in `opencode.json`, add `CLAUDE.md`.)*
- Start every session with Prompt 10 so it reads HANDOFF first.
- Checkpoint = Git commit + HANDOFF update. When returning to Claude web, build a ZIP with `make_checkpoint.sh` and upload it.

## Switching Claude accounts (recommended workflow)
1. **Before the limit (Account A):** when usage feels high, say: `Limits near. Do an emergency checkpoint: finish the current edit, fully update HANDOFF, attach the latest verified ZIP.` (If you hit the limit abruptly, use the last ZIP you downloaded; HANDOFF inside it tells what was done up to that point.)
2. **Download** the ZIP from Account A. Check the filename's checkpoint number is the newest.
3. **Open Account B**, new chat. Upload the ZIP. Paste Prompt 10.
4. **B confirms in 3 lines** (project, ZIP, next task) and continues. B must not re-explore the project.
5. **Repeat.** Each account continues checkpoint numbering (CP05 → CP06...).
6. **Optional safety:** push the same state to GitHub after each ZIP so you always have a second copy.

## Troubleshooting
| Problem | Fix |
|---|---|
| Claude says it "delivered" but no file | Ask: `Attach the latest ZIP now (ZIP_CHECKLIST.md). If you cannot, follow the recovery steps in DELIVERY_PROTOCOL.md.` |
| New account re-reads everything | Remind: `Follow CLAUDE.md session start. Read only HANDOFF.md.` |
| ZIP missing recent work | Use the latest CP; HANDOFF lists what happened after it |
| ZIP too large | Remove `node_modules`/caches; the script already excludes them |
