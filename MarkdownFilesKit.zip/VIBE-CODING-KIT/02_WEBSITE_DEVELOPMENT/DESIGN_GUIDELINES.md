# DESIGN_GUIDELINES.md

Defaults for a modern, polished interface. Override per project in `docs/PROJECT_BRIEF.md`. Follow the existing design if the site already has one.

## Foundations
- **Responsive:** design mobile-first; test at 360 px (mobile), 768 px (tablet), 1280 px (desktop). No horizontal scrolling.
- **Theme tokens:** define colors, spacing, radius, shadows as CSS variables in one place.
- **Palette:** 1 primary, 1 accent (optional), neutrals, and semantic colors (success green, warning amber, error red). Ensure readable contrast (text vs background at least 4.5:1).
- **Typography:** one sans-serif family (e.g. Inter or system fonts), base 16 px, clear scale (h1 to small), line height about 1.5.
- **Spacing:** use a consistent scale (4/8/16/24/32/48 px). Whitespace over borders.
- **Components:** reuse buttons, inputs, cards, tables, modals, alerts, badges. Same component = same look everywhere.

## Layout and navigation
- Clear primary navigation; current page highlighted.
- Desktop: top bar or sidebar. Mobile: collapsible menu or bottom bar.
- Consistent page structure: title, short description, main action, content.

## Required UI states (every data-driven screen)
| State | Requirement |
|---|---|
| Loading | Spinner or skeleton |
| Empty | Friendly message plus the next action |
| Success | Confirmation (toast or message) |
| Error | Clear, human message plus how to recover |
| Disabled | Visibly disabled; prevent double-submit |

## Forms
- Labels always visible; required fields marked.
- Inline validation messages next to fields; keep user input after an error.
- Correct input types (email, number, date); sensible autofocus and tab order.

## Interaction and accessibility
- Buttons and links look clickable and have hover/focus states. Tap targets at least 44 px on mobile.
- Alt text on images; semantic headings; keyboard-operable controls.
- Confirm destructive actions (delete).
- Subtle transitions only (150-250 ms). No flashy animation.

## Polished-look checklist
- [ ] Consistent spacing and alignment
- [ ] No default browser styling left visible
- [ ] Real-looking content (no "Lorem ipsum" or "Test123" in the final)
- [ ] Icons from one set
- [ ] Looks good on all three widths
- [ ] Favicon and page titles set

Looks are never a substitute for working features. See `TESTING_CHECKLIST.md`.
