# TESTING_CHECKLIST.md

A site is **not complete** until real functionality is tested. Exercise features; do not just read the code. Record results (pass/fail, date) in `docs/HANDOFF.md` under "Tests performed". Use the narrowest relevant section while developing; run all sections before the final ZIP.

## 1. Basic run
- [ ] App starts with no errors (server log, browser console)
- [ ] Database connects; schema and seed data load from scratch
- [ ] No broken links, missing images, or 404 on assets

## 2. Navigation and buttons
- [ ] Every nav link and button works and goes to the right place
- [ ] Back/refresh does not break state or duplicate submissions

## 3. Forms and validation
- [ ] Valid input saves correctly and shows success
- [ ] Empty, too long, wrong format, duplicate, and special-character input are rejected with clear messages
- [ ] Input is kept after validation errors

## 4. Authentication and authorization (if applicable)
- [ ] Register, login, logout, wrong password
- [ ] Protected pages redirect when logged out
- [ ] Each role sees only what it should; direct URL access by the wrong role is blocked
- [ ] Users cannot view or edit other users' data

## 5. Data and database
- [ ] Create, read, update, delete each work and persist after reload
- [ ] Relationships/foreign keys hold (no orphan records, deletes handled)
- [ ] Duplicates and invalid references are prevented

## 6. UI states
- [ ] Loading, empty, success, and error states appear where expected

## 7. Responsive
- [ ] 360 px, 768 px, 1280 px: no overflow, readable text, usable menus and tables

## 8. Security basics
- [ ] SQL injection and XSS attempts in inputs do not work
- [ ] Passwords are hashed; no secrets in the repo; uploads validated

## 9. Browsers
- [ ] Latest Chrome and one other (Firefox or Edge)

## Result log format
```
Test: <area> | Result: PASS/FAIL | Notes: <bug id if failed>
```
Failures go to `docs/KNOWN_ISSUES.md`. Mention in reports only what was actually tested.
