# KNOWN_ISSUES.md (template — live copy: `docs/KNOWN_ISSUES.md`)

One line per issue. Fixed issues move to the Resolved table; do not delete them.

## Open
| ID | Severity | Where (file/page) | Description | Steps to reproduce | Status |
|---|---|---|---|---|---|
| B-001 | High/Med/Low | | | | Open |

## Resolved
| ID | Fix summary | Fixed in checkpoint |
|---|---|---|

## Rules
- Severity: **High** = crashes, data loss, security hole, blocks a core feature; **Med** = feature partly broken; **Low** = cosmetic.
- Record bugs found but not fixed so the next account does not rediscover them.
- Do not hide a known High issue when reporting "complete".
