# ARCHITECTURE.md (template — live copy: `docs/ARCHITECTURE.md`)

This file doubles as the **inspection cache**: record what you learned so nobody re-reads the project. Keep it current and short.

## Stack
- Frontend:
- Backend:
- Database:
- Tools/versions:
- How to run locally:

## Folder structure (example — replace with the real one)
```
project/
  public/        entry point, assets (css, js, images, uploads)
  app/           controllers, models, services, views
  config/        settings (no secrets committed)
  database/      schema.sql, seed.sql
  docs/          HANDOFF.md, TASK_TRACKER.md, DECISIONS_LOG.md, ...
  tests/
```

## File map (one line each, key files only)
| File | Purpose |
|---|---|
| | |

## Data model
Tables/collections with key columns and relationships (e.g. `tasks.group_id → groups.id`).

## Roles and permissions
| Role | Can | Cannot |
|---|---|---|

## Main flows
Short numbered steps for each key workflow (e.g. login, submit form, checkout).

## Conventions
Naming, routing, error handling, and validation patterns used in this project.

## Rules
- Update after structural changes (new folder, table, route, role).
- Do not duplicate content from `PROJECT_BRIEF.md` or `CODING_STANDARDS.md`.
