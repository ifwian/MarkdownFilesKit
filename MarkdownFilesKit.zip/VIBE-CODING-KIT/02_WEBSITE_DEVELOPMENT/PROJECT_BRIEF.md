# PROJECT_BRIEF.md (template — live copy: `docs/PROJECT_BRIEF.md`)

Fill once at project start. Keep it under one page. Change only when the user changes scope.

- **Name:**
- **Purpose / problem solved:** (2 sentences)
- **Target users and roles:**
- **Tech stack (locked):** frontend / backend / database / hosting
- **Core features (MVP):**
  1.
- **Secondary features:**
- **Out of scope:**
- **Pages / screens:**
- **Data (main entities):**
- **Constraints:** deadline, team size, school requirements, no-go technologies
- **Success criteria:** how we know it is complete (link to `FINAL_REVIEW.md`)
- **References / inspirations:**
