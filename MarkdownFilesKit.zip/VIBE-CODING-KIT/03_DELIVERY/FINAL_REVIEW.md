# FINAL_REVIEW.md

Run before the final ZIP. "Complete" means every **Blocker** item passes. Do not mark the project complete otherwise. Details live in the linked files.

## Blockers (all must pass)
- [ ] Every MVP feature in `docs/PROJECT_BRIEF.md` works end to end (tested, not assumed)
- [ ] `TESTING_CHECKLIST.md` run in full; results recorded in HANDOFF
- [ ] No open **High** issues in `docs/KNOWN_ISSUES.md`
- [ ] Authentication/authorization verified for every role (if used)
- [ ] Validation and error handling on all forms
- [ ] Fresh setup works: following README from an empty database and clean folder
- [ ] No secrets in the project; `.env.example` provided
- [ ] Responsive at 360, 768, 1280 px
- [ ] No dead buttons, broken links, console errors

## Quality
- [ ] UI consistent with `DESIGN_GUIDELINES.md` (states, spacing, typography)
- [ ] Code follows `CODING_STANDARDS.md`; unused files and debug code removed
- [ ] No new dependencies beyond those logged in `DECISIONS_LOG.md`
- [ ] Database schema and seed files current
- [ ] `README.md` written from `README_TEMPLATE.md`
- [ ] `docs/ARCHITECTURE.md` matches the real structure

## Delivery
- [ ] HANDOFF finalized (status: complete, next task: none or future ideas)
- [ ] Final ZIP built per `ZIP_CHECKLIST.md` (`<Project>_CP<NN>_final.zip`), verified, attached
- [ ] Final reply (10 lines max): what works, what was tested, known low-severity issues, ZIP filename

## Honesty rule
List anything not tested or not working. Never claim "fully tested" unless it was.
