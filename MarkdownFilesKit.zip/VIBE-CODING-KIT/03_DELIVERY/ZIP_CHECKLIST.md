# ZIP_CHECKLIST.md

Packaging steps for every checkpoint. Rules and triggers are in `00_GLOBAL_RULES/DELIVERY_PROTOCOL.md`; this file does not repeat them.

## Before zipping
- [ ] All edits are saved in the live directory (nothing only in chat)
- [ ] Quick check passed (page loads / syntax check / relevant test)
- [ ] `docs/HANDOFF.md`, `TASK_TRACKER.md`, `KNOWN_ISSUES.md` updated
- [ ] No half-written code (or marked `TODO(WIP)` and listed in HANDOFF)

## Build (preferred)
```bash
bash docs/kit/03_DELIVERY/make_checkpoint.sh /home/claude/<Project> <Project> <NN> <label>
# example: bash make_checkpoint.sh /home/claude/Shop Shop 3 orders-done
```
The script zips the **whole** project, tests the archive, prints file count and size, and saves to `/mnt/user-data/outputs/` (or the current folder if that does not exist).

Manual equivalent:
```bash
cd /home/claude
zip -rq /mnt/user-data/outputs/Shop_CP03_orders-done.zip Shop -x "*/node_modules/*" "*/.git/*" "*/vendor/*" "*/.env" "*/__pycache__/*" "*/.cache/*" "*.DS_Store"
unzip -tq /mnt/user-data/outputs/Shop_CP03_orders-done.zip
```

## What goes in the ZIP
| Include | Exclude |
|---|---|
| All source, assets, `docs/`, `docs/kit/`, `CLAUDE.md`, schema/seed SQL, `.env.example` | `node_modules/`, `.git/`, `.env` and any secrets, caches, `__pycache__`, OS junk |
| Lock files (`package-lock.json`, `composer.lock`) | Large temporary files and logs |

Notes:
- `vendor/` is excluded by the script. If the next environment cannot run `composer install`, include it manually and say so in HANDOFF.
- Do not exclude folders just because they are named `build` or `dist` if they hold hand-written source.

## Verify (all must be true)
- [ ] ZIP file exists; size is plausible
- [ ] `unzip -tq` shows no errors
- [ ] `unzip -Z1 <zip> | grep -c .` file count roughly matches the project
- [ ] `docs/HANDOFF.md` and files changed in this milestone are inside (`unzip -Z1 <zip> | grep <name>`)
- [ ] No `.env`, passwords, or API keys inside

## Attach
- [ ] ZIP is in the output folder and presented/attached in this reply
- [ ] Reply states: filename + one-line summary (progress report format)
- [ ] Never say "delivered" if the attachment failed; use the recovery steps in `DELIVERY_PROTOCOL.md`

## After
- [ ] Record the filename in `TASK_TRACKER.md` (checkpoint column) and as "Latest ZIP" in HANDOFF
