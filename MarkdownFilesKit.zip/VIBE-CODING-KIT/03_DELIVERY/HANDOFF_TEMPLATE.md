# HANDOFF — [Project Name]  (live copy: `docs/HANDOFF.md`)

Edit in place; keep it short and factual. Process: `01_WORKFLOW/CLAUDE_HANDOFF.md`.

## 1. Project
- **Name:**
- **Version / checkpoint:** v0.x / CP[NN]
- **Latest complete ZIP:** `[filename].zip`
- **Last updated:** [date] by [account/tool]

## 2. Tech stack
Frontend: · Backend: · Database: · Tools/versions: · Run command:

## 3. Current status
[2-3 lines: what works now, what state the project is in. Mark `WIP` if something is broken.]

## 4. Completed tasks
- [Task ID] short description

## 5. Pending tasks
- [Task ID] short description (see `TASK_TRACKER.md`)

## 6. Files
- **Modified since last checkpoint:**
- **New:**
- **Deleted:**

## 7. Known bugs
- [B-ID] short description (see `KNOWN_ISSUES.md`)

## 8. Tests performed
| Area | Result | Date |
|---|---|---|
| | PASS/FAIL | |
(Anything not listed here was **not** tested.)

## 9. Architectural decisions
- [D-ID] short description (see `DECISIONS_LOG.md`)

## 10. Restrictions — do not change
- Keep the stack: [..]
- Do not modify: [files/areas and why]
- User rules: [..]

## 11. Exact next task
[File names, what to change, expected result, how to check it.]

## 12. Instructions for the next AI account
1. Unzip the latest ZIP; read `CLAUDE.md`, then this file only.
2. Verify the ZIP matches this handoff (filename, files above exist). If not, the ZIP wins; fix this file.
3. Do not redo completed tasks or re-inspect the whole project; use `docs/ARCHITECTURE.md`.
4. Continue with section 11, checkpointing per `DELIVERY_PROTOCOL.md`; next ZIP is CP[NN+1].
