#!/usr/bin/env bash
# make_checkpoint.sh — build and verify a full-project ZIP checkpoint.
# Usage: bash make_checkpoint.sh <project_dir> <ProjectName> <checkpoint_number> [label]
# Example: bash make_checkpoint.sh /home/claude/Shop Shop 3 orders-done
set -euo pipefail

DIR="${1:?Usage: make_checkpoint.sh <project_dir> <ProjectName> <NN> [label]}"
NAME="${2:?missing ProjectName}"
NN="${3:?missing checkpoint number}"
LABEL="${4:-checkpoint}"

[ -d "$DIR" ] || { echo "ERROR: project dir not found: $DIR"; exit 1; }

OUT="/mnt/user-data/outputs"
[ -d "$OUT" ] || OUT="$(pwd)"
FILE="$OUT/${NAME}_CP$(printf '%02d' "$((10#$NN))")_${LABEL}.zip"

PARENT="$(dirname "$DIR")"
BASE="$(basename "$DIR")"
cd "$PARENT"
rm -f "$FILE"
zip -rq "$FILE" "$BASE" \
  -x "*/node_modules/*" "*/.git/*" "*/vendor/*" "*/.env" "*/__pycache__/*" "*/.cache/*" "*.DS_Store"

unzip -tq "$FILE" >/dev/null || { echo "ERROR: ZIP failed integrity test"; exit 1; }
COUNT="$(unzip -Z1 "$FILE" | grep -vc '/$' || true)"
[ "$COUNT" -gt 0 ] || { echo "ERROR: ZIP is empty"; exit 1; }

if unzip -Z1 "$FILE" | grep -q 'docs/HANDOFF.md'; then
  echo "HANDOFF.md: present"
else
  echo "WARNING: docs/HANDOFF.md is missing from the ZIP. Update it before attaching."
fi
if unzip -Z1 "$FILE" | grep -Eq '(^|/)\.env$'; then
  echo "WARNING: .env found in ZIP. Remove it."
fi

echo "Files: $COUNT | Size: $(du -h "$FILE" | cut -f1)"
echo "ZIP OK: $FILE"
