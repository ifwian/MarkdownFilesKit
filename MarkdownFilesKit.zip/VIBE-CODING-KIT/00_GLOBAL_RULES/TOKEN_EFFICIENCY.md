# TOKEN_EFFICIENCY.md

Goal: finish more work per session. **Correctness always overrides token saving.** If saving tokens would risk a bug, spend the tokens.

## MANDATORY rules

### Reading
- Inspect each file **once**. After inspecting, record what matters in `docs/ARCHITECTURE.md` (file map) and do not re-open it unless it changed or you need exact lines.
- Find before reading: use `ls`, `find`, `grep -rn "name"` to locate code, then view only the needed line range.
- Read only files relevant to the current task. Do not "get familiar" with the whole project.
- Do not read lock files, minified files, build output, `node_modules`, `vendor`, images, or large data files.

### Writing
- Change small things with targeted edits (`str_replace`, patch). Rewrite a whole file only if more than about half of it changes or it is a new file.
- Do not generate code that was not requested (extra pages, demo data, unused helpers).
- Do not paste file contents into chat unless the user asks. Files on disk are the deliverable.
- Do not repeat information already in project docs. Refer to it.

### Talking
- No greetings, no restating the task, no explaining obvious steps, no closing summaries beyond the report format below.
- Ask questions only when blocked. Batch them in one message, max 3.
- Never describe what you created in detail. Say what changed and where.

### Planning
- Split work into independent milestones (one feature or fix each, roughly 10 files or fewer). Finish, check, checkpoint, then continue.
- Batch related tool calls (several edits in one command) instead of one call per edit.
- Run the narrowest check that proves the change (one test file, one page, a syntax check), not the whole suite every time.

## Progress report format (max 6 lines)
```
Done: <what changed, 1 line>
Files: <changed/new files, comma-separated>
Check: <what was verified and the result>
ZIP: <filename> (attached)
Next: <exact next task>
Issues: <only if any>
```

## Examples
| Wasteful | Efficient |
|---|---|
| Re-reading `style.css` (800 lines) before each tweak | `grep -n ".card" style.css`, view lines 120-150, edit that block |
| Rewriting `index.php` to change a title | One `str_replace` on the `<title>` line |
| "Great question! I will now begin by..." | Starts working, ends with the report format |
| Pasting 300 lines of code in chat after saving the file | "Updated `app/models/Task.php`" |

## *(Recommended)*
- Keep the `ARCHITECTURE.md` file map current so the next session skips exploration.
- In Claude Code use `/compact` or `/clear` between unrelated tasks.
- Start a new conversation (with the latest ZIP) when a chat becomes very long. See `01_WORKFLOW/CLAUDE_HANDOFF.md`.
