# CODING_STANDARDS.md

Adapt to the project's **actual stack**. Do not assume any language or framework.

## MANDATORY
- Preserve the existing stack, structure, and style. Change them only with user approval (log it in `DECISIONS_LOG.md`).
- No new dependency unless it clearly saves substantial work. Ask first and give the reason in one line.
- Beginner-friendly: simple, common methods a student can explain. No clever one-liners, no premature abstraction.
- Meaningful names (`getUserTasks`, not `gt`). One function = one job.
- Match the surrounding code's indentation, quotes, and naming.
- Validate input on the server, not only in the browser. Handle errors with clear user-facing messages.
- Never hard-code secrets. Use environment/config files and provide an `.env.example`.
- Database changes go through a schema/migration file; keep the SQL in the repo.
- Do not remove or rewrite working code unrelated to the task.
- Comments explain **why**, briefly. Give each new file a short header comment stating its purpose.

## Security basics (MANDATORY for websites)
- Prepared statements for all queries (never concatenate user input into SQL).
- Escape output to prevent XSS.
- Hash passwords (`password_hash`, `bcrypt`); never store plain text.
- Check authentication **and** role/ownership on every protected action, server-side.
- Validate file uploads (type, size, rename). Use CSRF protection for state-changing forms where the stack supports it.

## Stack notes (apply only what matches)
| Stack | Notes |
|---|---|
| HTML/CSS/JS | Semantic tags, CSS variables for theme, no inline styles, `const`/`let`, no jQuery unless already used |
| PHP | PDO, logic separated from views, one responsibility per class/file |
| MySQL | InnoDB, foreign keys, sensible types, indexes on lookup columns, `created_at`/`updated_at` |
| Node/Express | Thin routes, logic in services, async/await with try/catch |
| Python (Flask/Django) | Follow the framework's conventions |
| React/Vue (only if already used) | Small components, simple state |

## Structure
- Files short and focused (aim under about 300 lines; split when larger).
- Reuse components/partials for repeated UI (header, footer, nav, cards, forms).
- Configuration in one place; named constants, not magic numbers.

## Git *(Recommended)*
Commit messages: `feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `style:`. One logical change per commit.

## Done means
Runs without errors, the feature works end to end, edge cases and errors are handled, and the change is recorded in HANDOFF. See `02_WEBSITE_DEVELOPMENT/TESTING_CHECKLIST.md`.
