# CLAUDE.md — Project Rules (read first, every session)

Place this file in the **project root**. Rules marked **MANDATORY** are never skipped. Items marked *(Recommended)* are best practice.
A copy of the kit lives in `docs/kit/` (read its files **on demand only**, see table below).

## 1. Session start (MANDATORY)
1. Read `docs/HANDOFF.md` if it exists. Do not read other docs yet.
2. If a ZIP was supplied: unzip into the live directory and list the tree once (depth 3). Do not open every file.
3. Reply in max 3 lines: project, latest ZIP/checkpoint, next task. Then start working.
4. If HANDOFF and ZIP disagree, the **ZIP wins**; fix HANDOFF.

## 2. Core rules (details are in the linked files, not repeated here)
- **ZIP-first delivery:** the user must always be able to download the latest complete ZIP. → `DELIVERY_PROTOCOL.md`
- **Token efficiency:** read only what the task needs, edit small, report briefly, never trade away correctness. → `TOKEN_EFFICIENCY.md`
- **Code style:** beginner-friendly, same stack, no extra dependencies. → `CODING_STANDARDS.md`
- **Memory lives in files, not chat:** update `docs/HANDOFF.md`, `docs/TASK_TRACKER.md`, `docs/DECISIONS_LOG.md`, `docs/KNOWN_ISSUES.md` at every checkpoint.
- Never claim something is done, tested, or delivered unless it actually is.
- Do not change the technology stack, folder structure, or locked decisions without user approval.

## 3. Priority when rules conflict
1. Safety of the user's project and data (never delete or overwrite without a baseline)
2. The user's explicit instruction
3. Correctness
4. ZIP delivery
5. Token efficiency
6. Style and recommendations

## 4. Read on demand (files are in `docs/kit/`)
| Need | File |
|---|---|
| Making or sending a ZIP | `03_DELIVERY/ZIP_CHECKLIST.md` |
| Writing code | `00_GLOBAL_RULES/CODING_STANDARDS.md` |
| UI work | `02_WEBSITE_DEVELOPMENT/DESIGN_GUIDELINES.md` |
| Testing | `02_WEBSITE_DEVELOPMENT/TESTING_CHECKLIST.md` |
| Ending the project | `03_DELIVERY/FINAL_REVIEW.md` |
| Switching accounts | `01_WORKFLOW/CLAUDE_HANDOFF.md` |

## 5. Project docs (live files in `docs/`)
`HANDOFF.md` · `TASK_TRACKER.md` · `DECISIONS_LOG.md` · `KNOWN_ISSUES.md` · `PROJECT_BRIEF.md` · `ARCHITECTURE.md`
Templates for each are in the kit. Keep them short; edit lines, never rewrite whole files.

## 6. Response style (MANDATORY)
No introductions, no recaps of the request, no lists of what you "will do". The progress report format is in `TOKEN_EFFICIENCY.md`.
