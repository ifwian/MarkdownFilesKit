# DELIVERY_PROTOCOL.md — ZIP-FIRST DELIVERY (MANDATORY)

**Purpose:** the user must never lose work because a usage or context limit hit before a ZIP was delivered.
Packaging details: `03_DELIVERY/ZIP_CHECKLIST.md`. Helper script: `03_DELIVERY/make_checkpoint.sh`.

## Definitions
- **Live directory:** the single working copy of the project (e.g. `/home/claude/<Project>/`). All edits happen here.
- **Baseline:** untouched copy of the project as received (`<Project>_baseline/`, outside the live directory).
- **Checkpoint (CPnn):** a ZIP of the **entire** live directory at a working point.
- **Latest ZIP:** the newest checkpoint. It must contain **all** completed work, not only recent files.

## Non-negotiable rules
1. Never begin large work without a baseline.
2. Never keep changes only in chat. Save every edit to the live directory immediately.
3. Never wait until all tasks are done to create a ZIP.
4. Every ZIP is built from the full live directory (cumulative), never from a list of changed files.
5. Verify every ZIP before attaching (step 6).
6. Never say a ZIP was delivered unless it is attached or downloadable in this reply.
7. Update `docs/HANDOFF.md` before every ZIP.
8. Any turn that changed project files **ends with a fresh verified ZIP attached**.

## Procedure
1. **Inspect (once, cheap).** Unzip to the live directory. Show the tree to depth 3. Read `docs/HANDOFF.md` and `docs/ARCHITECTURE.md` only. Detect the stack from manifest files (`package.json`, `composer.json`, `requirements.txt`, `index.html`...).
2. **Baseline.** Copy the received project to `<Project>_baseline/`. If the project has Git, note the current commit. *(Recommended: commit "baseline" if Git is available.)*
3. **Plan milestones.** Write them to `docs/TASK_TRACKER.md` (one line each). Each milestone must leave the project in a working state.
4. **Work in the live directory only,** one milestone at a time.
5. **Checkpoint after each milestone:** quick check passes, update HANDOFF + TASK_TRACKER, build the ZIP, verify, attach.
6. **Verify the ZIP:**
   - The file exists and its size is plausible (not 0, not tiny).
   - `unzip -tq` reports no errors.
   - `docs/HANDOFF.md` and at least 2 files changed in this milestone are listed inside (`unzip -Z1 file.zip | grep ...`).
   - No `node_modules`, `.env`, or secrets inside.
7. **Attach.** Claude web: the ZIP must be in `/mnt/user-data/outputs/` and presented. State the filename and a one-line summary.
8. **End of turn.** The latest ZIP is attached. If nothing changed since the last ZIP, say "No changes since `<filename>`".
9. **Limit warning:** follow the emergency checkpoint below.

## Checkpoint triggers (whichever comes first)
| Trigger | Action |
|---|---|
| Baseline created and first milestone done | CP01 |
| Each milestone completed | Next CP |
| About 15-20 tool calls, or a long chat, since the last ZIP | Checkpoint now |
| Before a risky refactor, mass rename, or DB change | Checkpoint first |
| Any usage/context warning, or you suspect limits are near | Emergency checkpoint |
| Final task done | Final ZIP after `03_DELIVERY/FINAL_REVIEW.md` |

## Emergency checkpoint (limits near)
1. Stop starting new work. Bring the file you are editing to a consistent state (no half-written code). If unavoidable, mark the spot `TODO(WIP)` and list it in HANDOFF.
2. Update `docs/HANDOFF.md` (status, exact next task, what is broken).
3. Build and verify a ZIP. Use `wip` in the label if anything is broken.
4. Attach it. Reply with the progress report format only.

## Naming
`<ProjectName>_CP<NN>_<label>.zip` e.g. `SiftedCafe_CP03_auth-done.zip`, `SiftedCafe_CP07_wip.zip`, `SiftedCafe_CP12_final.zip`.
Only the latest ZIP matters.

## If files cannot be created or attached
State the limitation in one sentence, then use the best recovery method in order:
1. Save the ZIP to the output folder and give its exact path.
2. Provide only **changed/new files** as code blocks, in dependency order, plus a manifest of deleted files.
3. Provide the filled `HANDOFF.md` inline.
4. State clearly what is not delivered. Never imply a ZIP exists.

## Local tools (Claude Code, OpenCode)
Files are already on the user's disk. A checkpoint there = a **Git commit** (clear message) plus the same HANDOFF update. Make a ZIP only when transferring to Claude web or another account. Rules 2, 4, 6, 7 still apply whenever a ZIP is made.

## Example flow
Receive `Shop.zip` → unzip, tree, read HANDOFF → baseline copy → plan 4 milestones → M1 done → check → HANDOFF → `Shop_CP01_cart.zip` verified and attached → M2 and M3 → many tool calls → `Shop_CP02_orders.zip` attached → limit warning → finish current edit → `Shop_CP03_wip.zip` attached, next task written in HANDOFF.
