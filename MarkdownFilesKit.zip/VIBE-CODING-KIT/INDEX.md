# VIBE-CODING-KIT — Index

Reusable instruction system for AI-assisted website projects (Claude web, Claude Code, OpenCode). Priorities: **token efficiency** and **guaranteed ZIP delivery**.

## Structure
```
VIBE-CODING-KIT/
  INDEX.md                      this file
  USAGE_GUIDE.md                setup for Claude web / Claude Code / OpenCode, account switching
  00_GLOBAL_RULES/
  01_WORKFLOW/
  02_WEBSITE_DEVELOPMENT/
  03_DELIVERY/
```

## Files
| File | Purpose | Type |
|---|---|---|
| `00_GLOBAL_RULES/CLAUDE.md` | Short entry rules; goes in the project root | Rules |
| `00_GLOBAL_RULES/TOKEN_EFFICIENCY.md` | Reading/writing/reporting rules to save tokens | Rules |
| `00_GLOBAL_RULES/DELIVERY_PROTOCOL.md` | ZIP-first delivery protocol (the core rule set) | Rules |
| `00_GLOBAL_RULES/CODING_STANDARDS.md` | Beginner-friendly, stack-adaptive coding rules | Rules |
| `01_WORKFLOW/CLAUDE_HANDOFF.md` | How to move work between accounts/sessions | Process |
| `01_WORKFLOW/TASK_TRACKER.md` | Milestone/task tracking template | Template |
| `01_WORKFLOW/DECISIONS_LOG.md` | Locked decisions and decision history | Template |
| `01_WORKFLOW/PROMPT_TEMPLATES.md` | 12 short reusable prompts | Prompts |
| `02_WEBSITE_DEVELOPMENT/PROJECT_BRIEF.md` | One-page project definition | Template |
| `02_WEBSITE_DEVELOPMENT/DESIGN_GUIDELINES.md` | Responsive, modern UI defaults and required states | Guide |
| `02_WEBSITE_DEVELOPMENT/ARCHITECTURE.md` | Structure, file map, data model (also an inspection cache) | Template |
| `02_WEBSITE_DEVELOPMENT/TESTING_CHECKLIST.md` | Functional test checklist | Checklist |
| `02_WEBSITE_DEVELOPMENT/KNOWN_ISSUES.md` | Bug log template | Template |
| `02_WEBSITE_DEVELOPMENT/README_TEMPLATE.md` | Project README template | Template |
| `03_DELIVERY/ZIP_CHECKLIST.md` | Build, verify, attach steps | Checklist |
| `03_DELIVERY/make_checkpoint.sh` | Script: builds and verifies a full ZIP | Tool |
| `03_DELIVERY/FINAL_REVIEW.md` | Completion gate | Checklist |
| `03_DELIVERY/HANDOFF_TEMPLATE.md` | Fill-in handoff form (becomes `docs/HANDOFF.md`) | Template |

## How the files relate (no duplication)
- `CLAUDE.md` is the short entry point and links to everything else.
- Delivery rules exist only in `DELIVERY_PROTOCOL.md`; `ZIP_CHECKLIST.md` only covers packaging steps.
- Handoff **process** = `CLAUDE_HANDOFF.md`; handoff **form** = `HANDOFF_TEMPLATE.md`.

## Mandatory vs recommended
Items marked **MANDATORY** are required. Items marked *(Recommended)* are optional best practice.
